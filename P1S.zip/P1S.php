<?php
declare(strict_types=1);

/*
 * Pilote du modèle Bambu Lab P1S.
 * Toute la logique propre à cette imprimante reste dans imprimantes/P1S/.
 *
 * Connexions locales utilisées :
 * - MQTT TLS : port 8883, utilisateur bblp, code d'accès LAN, numéro de série.
 * - FTPS implicite : port 990, utilisateur bblp, code d'accès LAN.
 * - Caméra JPEG TLS : port 6000, utilisateur bblp, code d'accès LAN.
 *
 * Le pilote n'enregistre jamais le code d'accès LAN dans son cache.
 */

$options = is_array($device['options'] ?? null) ? $device['options'] : [];
$host = trim((string)($device['host'] ?? ''));
$serial = trim((string)(
    $device['serial']
    ?? $device['serial_number']
    ?? $device['device_id']
    ?? $options['serial']
    ?? $options['serial_number']
    ?? $options['device_id']
    ?? ''
));
$accessCode = trim((string)(
    $options['access_code']
    ?? $options['lan_access_code']
    ?? $options['dev_access_code']
    ?? $options['password']
    ?? $device['access_code']
    ?? ''
));

$mqttPort = max(1, min(65535, (int)($options['mqtt_port'] ?? 8883)));
$ftpPort = max(1, min(65535, (int)($options['ftp_port'] ?? 990)));
$cameraPort = max(1, min(65535, (int)($options['camera_port'] ?? 6000)));
$connectTimeout = max(1.0, min(20.0, (float)($options['connect_timeout'] ?? 4.0)));
$mqttListenSeconds = max(0.5, min(12.0, (float)($options['mqtt_listen_seconds'] ?? 2.5)));
$printingRefreshSeconds = max(3, min(300, (int)($options['printing_refresh_seconds'] ?? 10)));
$idleRefreshSeconds = max(10, min(900, (int)($options['idle_refresh_seconds'] ?? 60)));
$fileRefreshSeconds = max(10, min(3600, (int)($options['file_refresh_seconds'] ?? 120)));
$uploadDirectory = trim((string)($options['upload_directory'] ?? 'cache'), "/ \\t\n\r\0\x0B");
$uploadDirectory = preg_replace('~[^A-Za-z0-9._/-]+~', '_', $uploadDirectory) ?: 'cache';

$configuredCameraUrl = trim((string)($device['camera_url'] ?? ($options['camera_url'] ?? '')));
$cameraMode = trim((string)($options['camera_mode'] ?? 'jpeg_base64'));
$cameraEndpoint = trim((string)($options['camera_endpoint'] ?? ''));

$nozzleOptions = is_array($options['nozzle'] ?? null) ? $options['nozzle'] : [];
$configuredNozzleMaterial = dmd3d_clean_text((string)(
    $nozzleOptions['material'] ?? $options['nozzle_material'] ?? ''
), 80);
$configuredNozzleModel = dmd3d_clean_text((string)(
    $nozzleOptions['model'] ?? $options['nozzle_model'] ?? ''
), 120);

$cacheRoot = trim((string)($options['cache_dir'] ?? ''));
if ($cacheRoot === '') {
    $cacheRoot = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'dmd3dprint-p1s';
}
if (!is_dir($cacheRoot)) {
    @mkdir($cacheRoot, 0700, true);
}
$cacheKey = hash('sha256', strtolower($host) . '|' . strtoupper($serial));
$statusCacheFile = rtrim($cacheRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $cacheKey . '-status.json';
$filesCacheFile = rtrim($cacheRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $cacheKey . '-files.json';

$capabilities = [
    'camera' => true,
    'upload' => true,
    'print_control' => true,
    'light' => true,
    'fans' => ['part', 'aux', 'chamber'],
    'files' => true,
    'cfs' => true,
    'ams' => true,
    'plug' => false,
    'details' => true,
];

$requireConnectionData = static function () use ($host, $serial, $accessCode): void {
    if ($host === '') {
        throw new RuntimeException('L’adresse IP ou le nom réseau de la Bambu Lab P1S est manquant.');
    }
    if ($serial === '') {
        throw new RuntimeException('Le numéro de série de la Bambu Lab P1S est manquant.');
    }
    if ($accessCode === '') {
        throw new RuntimeException('Le code d’accès LAN de la Bambu Lab P1S est manquant.');
    }
};

$isListArray = static function (array $value): bool {
    if (function_exists('array_is_list')) {
        return array_is_list($value);
    }
    return array_keys($value) === range(0, count($value) - 1);
};

$deepMerge = static function (array $base, array $update) use (&$deepMerge, $isListArray): array {
    foreach ($update as $key => $value) {
        if (
            isset($base[$key])
            && is_array($base[$key])
            && is_array($value)
            && !$isListArray($base[$key])
            && !$isListArray($value)
        ) {
            $base[$key] = $deepMerge($base[$key], $value);
        } else {
            $base[$key] = $value;
        }
    }
    return $base;
};

$readJsonCache = static function (string $path): array {
    if (!is_file($path) || !is_readable($path)) {
        return [];
    }
    $raw = @file_get_contents($path);
    if (!is_string($raw) || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
};

$writeJsonCache = static function (string $path, array $data): void {
    $directory = dirname($path);
    if (!is_dir($directory)) {
        @mkdir($directory, 0700, true);
    }
    $encoded = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($encoded)) {
        return;
    }
    $temporary = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($temporary, $encoded, LOCK_EX) !== false) {
        @chmod($temporary, 0600);
        @rename($temporary, $path);
    } else {
        @unlink($temporary);
    }
};

$mqttEncodeLength = static function (int $length): string {
    if ($length < 0 || $length > 268435455) {
        throw new InvalidArgumentException('Longueur MQTT invalide.');
    }
    $encoded = '';
    do {
        $digit = $length % 128;
        $length = intdiv($length, 128);
        if ($length > 0) {
            $digit |= 0x80;
        }
        $encoded .= chr($digit);
    } while ($length > 0);
    return $encoded;
};

$mqttString = static function (string $value): string {
    $length = strlen($value);
    if ($length > 65535) {
        throw new InvalidArgumentException('Chaîne MQTT trop longue.');
    }
    return pack('n', $length) . $value;
};

$socketWriteAll = static function ($socket, string $data): void {
    $offset = 0;
    $length = strlen($data);
    while ($offset < $length) {
        $written = @fwrite($socket, substr($data, $offset));
        if (!is_int($written) || $written <= 0) {
            throw new RuntimeException('La connexion réseau avec la P1S a été interrompue pendant l’envoi.');
        }
        $offset += $written;
    }
};

$socketReadExact = static function ($socket, int $length, float $deadline): string {
    $data = '';
    while (strlen($data) < $length) {
        if (microtime(true) >= $deadline) {
            throw new RuntimeException('Délai dépassé pendant la lecture de la réponse de la P1S.');
        }
        $chunk = @fread($socket, $length - strlen($data));
        if ($chunk === false) {
            throw new RuntimeException('Erreur de lecture sur la connexion avec la P1S.');
        }
        if ($chunk === '') {
            $metadata = stream_get_meta_data($socket);
            if (!empty($metadata['timed_out'])) {
                throw new RuntimeException('Délai dépassé pendant la lecture de la réponse de la P1S.');
            }
            if (!empty($metadata['eof'])) {
                throw new RuntimeException('La P1S a fermé la connexion réseau.');
            }
            usleep(10000);
            continue;
        }
        $data .= $chunk;
    }
    return $data;
};

$mqttReadPacket = static function ($socket, float $deadline) use ($socketReadExact): ?array {
    while (microtime(true) < $deadline) {
        $first = @fread($socket, 1);
        if ($first === false) {
            throw new RuntimeException('Erreur de lecture MQTT.');
        }
        if ($first === '') {
            $metadata = stream_get_meta_data($socket);
            if (!empty($metadata['eof'])) {
                return null;
            }
            usleep(10000);
            continue;
        }

        $multiplier = 1;
        $remaining = 0;
        $bytes = 0;
        do {
            $encodedByte = ord($socketReadExact($socket, 1, $deadline));
            $remaining += ($encodedByte & 127) * $multiplier;
            $multiplier *= 128;
            $bytes++;
            if ($bytes > 4) {
                throw new RuntimeException('Paquet MQTT invalide reçu de la P1S.');
            }
        } while (($encodedByte & 128) !== 0);

        $body = $remaining > 0 ? $socketReadExact($socket, $remaining, $deadline) : '';
        return [
            'header' => ord($first),
            'type' => ord($first) >> 4,
            'flags' => ord($first) & 0x0F,
            'body' => $body,
        ];
    }
    return null;
};

$mqttOpen = static function () use (
    $host,
    $mqttPort,
    $accessCode,
    $serial,
    $connectTimeout,
    $mqttEncodeLength,
    $mqttString,
    $socketWriteAll,
    $mqttReadPacket
) {
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
            'SNI_enabled' => false,
            'capture_peer_cert' => false,
        ],
    ]);

    $errorNumber = 0;
    $errorMessage = '';
    $socket = @stream_socket_client(
        'tls://' . $host . ':' . $mqttPort,
        $errorNumber,
        $errorMessage,
        $connectTimeout,
        STREAM_CLIENT_CONNECT,
        $context
    );
    if (!is_resource($socket)) {
        throw new RuntimeException(
            'Connexion MQTT impossible avec la P1S'
            . ($errorMessage !== '' ? ' : ' . $errorMessage : ' (erreur ' . $errorNumber . ')')
        );
    }

    stream_set_blocking($socket, false);
    stream_set_timeout($socket, (int)ceil($connectTimeout));

    $clientId = 'dmd3d-' . substr(hash('sha256', $serial . '|' . microtime(true) . '|' . random_int(1, PHP_INT_MAX)), 0, 18);
    $connectFlags = 0x02 | 0x80 | 0x40;
    $variableHeader = $mqttString('MQTT') . chr(4) . chr($connectFlags) . pack('n', 30);
    $payload = $mqttString($clientId) . $mqttString('bblp') . $mqttString($accessCode);
    $packet = chr(0x10) . $mqttEncodeLength(strlen($variableHeader) + strlen($payload)) . $variableHeader . $payload;
    $socketWriteAll($socket, $packet);

    $connAck = $mqttReadPacket($socket, microtime(true) + $connectTimeout);
    if (!is_array($connAck) || ($connAck['type'] ?? 0) !== 2 || strlen((string)($connAck['body'] ?? '')) < 2) {
        @fclose($socket);
        throw new RuntimeException('La P1S n’a pas renvoyé de confirmation MQTT valide.');
    }
    $returnCode = ord($connAck['body'][1]);
    if ($returnCode !== 0) {
        @fclose($socket);
        $messages = [
            1 => 'version MQTT refusée',
            2 => 'identifiant client refusé',
            3 => 'serveur MQTT indisponible',
            4 => 'identifiants MQTT refusés',
            5 => 'accès MQTT non autorisé',
        ];
        throw new RuntimeException('Connexion MQTT refusée par la P1S : ' . ($messages[$returnCode] ?? ('code ' . $returnCode)) . '.');
    }

    return $socket;
};

$mqttSubscribe = static function ($socket, string $topic, int $packetId = 1) use (
    $mqttString,
    $mqttEncodeLength,
    $socketWriteAll,
    $mqttReadPacket,
    $connectTimeout
): void {
    $body = pack('n', $packetId) . $mqttString($topic) . chr(0);
    $socketWriteAll($socket, chr(0x82) . $mqttEncodeLength(strlen($body)) . $body);
    $deadline = microtime(true) + $connectTimeout;
    while (($packet = $mqttReadPacket($socket, $deadline)) !== null) {
        if (($packet['type'] ?? 0) === 9) {
            return;
        }
    }
    throw new RuntimeException('La P1S n’a pas confirmé l’abonnement MQTT.');
};

$mqttPublish = static function (
    $socket,
    string $topic,
    string $payload,
    int $qos = 0,
    int $packetId = 2
) use ($mqttString, $mqttEncodeLength, $socketWriteAll): void {
    $qos = $qos === 1 ? 1 : 0;
    $header = $qos === 1 ? 0x32 : 0x30;
    $body = $mqttString($topic);
    if ($qos === 1) {
        $body .= pack('n', $packetId);
    }
    $body .= $payload;
    $socketWriteAll($socket, chr($header) . $mqttEncodeLength(strlen($body)) . $body);
};

$mqttCollect = static function ($socket, float $seconds) use (
    $mqttReadPacket,
    $socketWriteAll
): array {
    $messages = [];
    $deadline = microtime(true) + $seconds;

    while (microtime(true) < $deadline) {
        $packet = $mqttReadPacket($socket, $deadline);
        if ($packet === null) {
            break;
        }

        $type = (int)($packet['type'] ?? 0);
        $body = (string)($packet['body'] ?? '');
        if ($type === 3 && strlen($body) >= 2) {
            $topicLength = unpack('nlength', substr($body, 0, 2));
            $topicLength = (int)($topicLength['length'] ?? 0);
            if ($topicLength < 0 || strlen($body) < 2 + $topicLength) {
                continue;
            }
            $offset = 2 + $topicLength;
            $qos = (($packet['header'] ?? 0) >> 1) & 0x03;
            $packetId = null;
            if ($qos > 0 && strlen($body) >= $offset + 2) {
                $idData = unpack('nid', substr($body, $offset, 2));
                $packetId = (int)($idData['id'] ?? 0);
                $offset += 2;
            }
            $json = substr($body, $offset);
            $decoded = json_decode($json, true);
            if (is_array($decoded)) {
                $messages[] = $decoded;
            }
            if ($qos === 1 && $packetId !== null) {
                $socketWriteAll($socket, chr(0x40) . chr(0x02) . pack('n', $packetId));
            }
        } elseif ($type === 13) {
            continue;
        }
    }

    return $messages;
};

$mqttExchange = static function (array $requests, float $listenSeconds, int $qos = 0) use (
    $requireConnectionData,
    $mqttOpen,
    $mqttSubscribe,
    $mqttPublish,
    $mqttCollect,
    $serial
): array {
    $requireConnectionData();
    $socket = $mqttOpen();
    try {
        $reportTopic = 'device/' . $serial . '/report';
        $requestTopic = 'device/' . $serial . '/request';
        $mqttSubscribe($socket, $reportTopic, 1);
        $packetId = 10;
        foreach ($requests as $request) {
            $encoded = json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (!is_string($encoded)) {
                throw new RuntimeException('Impossible de préparer la commande MQTT pour la P1S.');
            }
            $mqttPublish($socket, $requestTopic, $encoded, $qos, $packetId++);
        }
        return $mqttCollect($socket, $listenSeconds);
    } finally {
        if (is_resource($socket)) {
            @fwrite($socket, chr(0xE0) . chr(0));
            @fclose($socket);
        }
    }
};

$nextSequence = static function (): string {
    return (string)((int)(microtime(true) * 1000) % 2147483647);
};

$collectPrinterData = static function (bool $force = false) use (
    $readJsonCache,
    $writeJsonCache,
    $statusCacheFile,
    $printingRefreshSeconds,
    $idleRefreshSeconds,
    $mqttExchange,
    $mqttListenSeconds,
    $nextSequence,
    $deepMerge
): array {
    $cache = $readJsonCache($statusCacheFile);
    $state = is_array($cache['state'] ?? null) ? $cache['state'] : [];
    $info = is_array($cache['info'] ?? null) ? $cache['info'] : [];
    $updatedAt = (int)($cache['updated_at'] ?? 0);
    $gcodeState = strtoupper(trim((string)($state['gcode_state'] ?? '')));
    $isPrinting = in_array($gcodeState, ['RUNNING', 'PAUSE', 'PREPARE', 'SLICING', 'INIT'], true);
    $maxAge = $isPrinting ? $printingRefreshSeconds : $idleRefreshSeconds;

    if (!$force && $state !== [] && $updatedAt > 0 && (time() - $updatedAt) < $maxAge) {
        return [
            'state' => $state,
            'info' => $info,
            'updated_at' => $updatedAt,
            'from_cache' => true,
        ];
    }

    $sequence = $nextSequence();
    $messages = $mqttExchange([
        [
            'pushing' => [
                'sequence_id' => $sequence,
                'command' => 'pushall',
                'version' => 1,
                'push_target' => 1,
            ],
        ],
        [
            'info' => [
                'sequence_id' => (string)((int)$sequence + 1),
                'command' => 'get_version',
            ],
        ],
    ], $mqttListenSeconds, 0);

    foreach ($messages as $message) {
        if (is_array($message['print'] ?? null)) {
            $state = $deepMerge($state, $message['print']);
        }
        if (is_array($message['info'] ?? null)) {
            $info = $deepMerge($info, $message['info']);
        }
    }

    if ($state === []) {
        throw new RuntimeException('La P1S est joignable, mais aucun état MQTT exploitable n’a été reçu.');
    }

    $updatedAt = time();
    $writeJsonCache($statusCacheFile, [
        'state' => $state,
        'info' => $info,
        'updated_at' => $updatedAt,
    ]);

    return [
        'state' => $state,
        'info' => $info,
        'updated_at' => $updatedAt,
        'from_cache' => false,
    ];
};

$cleanColor = static function ($value): string {
    if (is_array($value)) {
        $value = $value[0] ?? '';
    }
    $color = strtoupper(trim((string)$value));
    $color = preg_replace('/^(#|0X)/i', '', $color) ?? '';
    if (preg_match('/^[0-9A-F]{8}$/', $color)) {
        $alpha = substr($color, 6, 2);
        if ($alpha === '00' && substr($color, 0, 6) === '000000') {
            return '';
        }
        return '#' . substr($color, 0, 6);
    }
    if (preg_match('/^[0-9A-F]{6}$/', $color)) {
        return '#' . $color;
    }
    return '';
};

$isMeaningful = static function ($value): bool {
    if ($value === null) {
        return false;
    }
    $text = strtoupper(trim((string)$value));
    return !in_array($text, ['', '0', '00000000', '0000000000000000', '00000000000000000000000000000000', '-1', 'NONE', 'NULL', 'UNKNOWN', 'N/A'], true);
};

$parseAms = static function (array $print) use ($cleanColor, $isMeaningful): array {
    $amsRoot = is_array($print['ams'] ?? null) ? $print['ams'] : [];
    $units = is_array($amsRoot['ams'] ?? null) ? array_values($amsRoot['ams']) : [];
    $trayNow = is_numeric($amsRoot['tray_now'] ?? null) ? (int)$amsRoot['tray_now'] : 255;
    $slots = [];
    $unitDetails = [];

    foreach ($units as $unitIndex => $unit) {
        if (!is_array($unit)) {
            continue;
        }
        $unitId = is_numeric($unit['id'] ?? null) ? (int)$unit['id'] : $unitIndex;
        $trays = is_array($unit['tray'] ?? null) ? array_values($unit['tray']) : [];
        $unitDetails[] = [
            'id' => $unitId,
            'label' => 'AMS ' . ($unitId + 1),
            'temperature' => is_numeric($unit['temp'] ?? null) ? round((float)$unit['temp'], 1) : null,
            'humidity' => is_numeric($unit['humidity'] ?? null) ? (float)$unit['humidity'] : null,
        ];

        for ($trayIndex = 0; $trayIndex < 4; $trayIndex++) {
            $tray = is_array($trays[$trayIndex] ?? null) ? $trays[$trayIndex] : [];
            $trayId = is_numeric($tray['id'] ?? null) ? (int)$tray['id'] : $trayIndex;
            $globalId = ($unitId * 4) + $trayId;
            $type = trim((string)($tray['tray_type'] ?? ''));
            $profile = trim((string)($tray['tray_info_idx'] ?? ''));
            $name = trim((string)($tray['tray_id_name'] ?? ''));
            $vendor = trim((string)($tray['tray_sub_brands'] ?? ''));
            $color = $cleanColor($tray['tray_color'] ?? ($tray['cols'] ?? ''));
            $present = $type !== '' || $profile !== '' || $name !== '' || $vendor !== '' || $color !== '' || $isMeaningful($tray['tag_uid'] ?? null);

            $slots[] = [
                'slot' => 'AMS' . ($unitId + 1) . '-' . chr(65 + $trayId),
                'unit' => 'AMS ' . ($unitId + 1),
                'unit_id' => $unitId,
                'slot_id' => $trayId,
                'global_id' => $globalId,
                'label' => chr(65 + $trayId),
                'type' => $present ? dmd3d_clean_text($type !== '' ? $type : $name, 80) : '',
                'material_code' => $present ? dmd3d_clean_text($profile, 80) : '',
                'name' => $present ? dmd3d_clean_text($name, 120) : '',
                'color' => $color,
                'present' => $present,
                'identified' => $type !== '' || $profile !== '' || $color !== '',
                'active' => $present && $trayNow === $globalId,
                'vendor' => $present ? dmd3d_clean_text($vendor, 120) : '',
                'remain_percent' => is_numeric($tray['remain'] ?? null) ? max(0, min(100, (float)$tray['remain'])) : null,
                'nozzle_temp_min' => is_numeric($tray['nozzle_temp_min'] ?? null) ? (float)$tray['nozzle_temp_min'] : null,
                'nozzle_temp_max' => is_numeric($tray['nozzle_temp_max'] ?? null) ? (float)$tray['nozzle_temp_max'] : null,
                'tray_weight' => is_numeric($tray['tray_weight'] ?? null) ? (float)$tray['tray_weight'] : null,
                'rfid_uid' => $isMeaningful($tray['tag_uid'] ?? null) ? dmd3d_clean_text((string)$tray['tag_uid'], 80) : '',
            ];
        }
    }

    $externalTray = is_array($print['vt_tray'] ?? null) ? $print['vt_tray'] : [];
    $externalType = trim((string)($externalTray['tray_type'] ?? ''));
    $externalProfile = trim((string)($externalTray['tray_info_idx'] ?? ''));
    $externalName = trim((string)($externalTray['tray_id_name'] ?? ''));
    $externalVendor = trim((string)($externalTray['tray_sub_brands'] ?? ''));
    $externalColor = $cleanColor($externalTray['tray_color'] ?? ($externalTray['cols'] ?? ''));
    $externalPresent = $externalType !== '' || $externalProfile !== '' || $externalName !== '' || $externalVendor !== '' || $externalColor !== '';

    $firstUnit = $unitDetails[0] ?? [];
    return [
        'available' => $units !== [] || $isMeaningful($amsRoot['ams_exist_bits'] ?? null),
        'state' => $units !== [] ? 'Connecté' : 'Non détecté',
        'status_code' => $print['ams_status'] ?? null,
        'rfid_status' => $print['ams_rfid_status'] ?? null,
        'temperature' => $firstUnit['temperature'] ?? null,
        'humidity' => $firstUnit['humidity'] ?? null,
        'units' => $unitDetails,
        'external' => [
            'label' => 'Porte-bobine externe',
            'type' => $externalPresent ? dmd3d_clean_text($externalType !== '' ? $externalType : $externalName, 80) : '',
            'material_code' => $externalPresent ? dmd3d_clean_text($externalProfile, 80) : '',
            'name' => $externalPresent ? dmd3d_clean_text($externalName, 120) : '',
            'color' => $externalColor,
            'present' => $externalPresent,
            'identified' => $externalType !== '' || $externalProfile !== '' || $externalColor !== '',
            'active' => $externalPresent && $trayNow === 254,
            'vendor' => $externalPresent ? dmd3d_clean_text($externalVendor, 120) : '',
            'remain_percent' => is_numeric($externalTray['remain'] ?? null) ? max(0, min(100, (float)$externalTray['remain'])) : null,
        ],
        'slots' => $slots,
        'tray_now' => $trayNow,
        'synced_at' => time(),
    ];
};

$fanPercent = static function ($value): ?int {
    if (!is_numeric($value)) {
        return null;
    }
    $numeric = max(0.0, (float)$value);
    if ($numeric <= 15.0) {
        return max(0, min(100, (int)round(($numeric / 15.0) * 100)));
    }
    if ($numeric <= 100.0) {
        return max(0, min(100, (int)round($numeric)));
    }
    return max(0, min(100, (int)round(($numeric / 255.0) * 100)));
};

$lightState = static function (array $print): ?bool {
    $reports = is_array($print['lights_report'] ?? null) ? $print['lights_report'] : [];
    foreach ($reports as $report) {
        if (!is_array($report) || strtolower(trim((string)($report['node'] ?? ''))) !== 'chamber_light') {
            continue;
        }
        $mode = strtolower(trim((string)($report['mode'] ?? '')));
        if ($mode === 'on' || $mode === 'flashing') {
            return true;
        }
        if ($mode === 'off') {
            return false;
        }
    }
    return null;
};

$stateLabel = static function (string $state): string {
    $state = strtoupper(trim($state));
    $map = [
        'IDLE' => 'Prête',
        'RUNNING' => 'Impression en cours',
        'PAUSE' => 'En pause',
        'PREPARE' => 'Préparation',
        'SLICING' => 'Préparation du fichier',
        'FINISH' => 'Impression terminée',
        'FAILED' => 'Impression échouée',
        'CANCELLED' => 'Impression annulée',
        'OFFLINE' => 'Hors ligne',
    ];
    return $map[$state] ?? ($state !== '' ? $state : 'En ligne');
};

$parseMlsd = static function (string $listing, string $directory): array {
    $files = [];
    foreach (preg_split('/\r\n|\n|\r/', $listing) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $facts = [];
        $name = $line;
        if (str_contains($line, ' ')) {
            [$factText, $name] = explode(' ', $line, 2);
            foreach (explode(';', $factText) as $fact) {
                if (!str_contains($fact, '=')) {
                    continue;
                }
                [$key, $value] = explode('=', $fact, 2);
                $facts[strtolower(trim($key))] = trim($value);
            }
        }
        $name = trim($name);
        if ($name === '' || $name === '.' || $name === '..') {
            continue;
        }
        $type = strtolower((string)($facts['type'] ?? 'file'));
        if ($type === 'dir' || $type === 'cdir' || $type === 'pdir') {
            continue;
        }
        $path = trim($directory . '/' . $name, '/');
        $modified = null;
        if (preg_match('/^\d{14}$/', (string)($facts['modify'] ?? ''))) {
            $date = DateTimeImmutable::createFromFormat('YmdHis', (string)$facts['modify'], new DateTimeZone('UTC'));
            if ($date instanceof DateTimeImmutable) {
                $modified = $date->getTimestamp();
            }
        }
        $files[] = [
            'name' => dmd3d_clean_text($name, 255),
            'path' => dmd3d_clean_text($path, 500),
            'size' => is_numeric($facts['size'] ?? null) ? (int)$facts['size'] : null,
            'modified' => $modified,
            'directory' => dmd3d_clean_text($directory, 120),
        ];
    }
    return $files;
};

$ftpsRequest = static function (
    string $remotePath,
    array $curlOptions = []
) use ($host, $ftpPort, $accessCode, $connectTimeout) {
    if (!function_exists('curl_init')) {
        throw new RuntimeException('L’extension PHP cURL est nécessaire pour utiliser le FTPS de la P1S.');
    }

    $segments = array_filter(explode('/', str_replace('\\', '/', trim($remotePath, '/'))), static fn(string $segment): bool => $segment !== '');
    $encodedPath = implode('/', array_map('rawurlencode', $segments));
    $url = 'ftps://' . $host . ':' . $ftpPort . '/' . $encodedPath;
    if ($remotePath === '' || str_ends_with($remotePath, '/')) {
        $url .= str_ends_with($url, '/') ? '' : '/';
    }

    $handle = curl_init($url);
    if ($handle === false) {
        throw new RuntimeException('Impossible de préparer la connexion FTPS avec la P1S.');
    }

    $defaults = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => 'bblp:' . $accessCode,
        CURLOPT_CONNECTTIMEOUT => (int)ceil($connectTimeout),
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_FTP_USE_EPSV => true,
    ];
    if (defined('CURLOPT_USE_SSL') && defined('CURLUSESSL_ALL')) {
        $defaults[CURLOPT_USE_SSL] = CURLUSESSL_ALL;
    }
    if (defined('CURLOPT_FTPSSLAUTH') && defined('CURLFTPAUTH_TLS')) {
        $defaults[CURLOPT_FTPSSLAUTH] = CURLFTPAUTH_TLS;
    }

    curl_setopt_array($handle, $curlOptions + $defaults);
    $body = curl_exec($handle);
    $error = curl_error($handle);
    $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
    curl_close($handle);

    if ($body === false || ($status >= 400 && $status !== 0)) {
        throw new RuntimeException(
            'Échec de la connexion FTPS avec la P1S'
            . ($error !== '' ? ' : ' . $error : ($status > 0 ? ' (FTP ' . $status . ')' : ''))
        );
    }
    return $body;
};

$listFiles = static function (bool $force = false) use (
    $requireConnectionData,
    $readJsonCache,
    $writeJsonCache,
    $filesCacheFile,
    $fileRefreshSeconds,
    $ftpsRequest,
    $parseMlsd
): array {
    $cached = $readJsonCache($filesCacheFile);
    if (
        !$force
        && is_array($cached['files'] ?? null)
        && (int)($cached['updated_at'] ?? 0) > 0
        && (time() - (int)$cached['updated_at']) < $fileRefreshSeconds
    ) {
        return $cached['files'];
    }

    $requireConnectionData();
    $files = [];
    foreach (['', 'cache'] as $directory) {
        $path = $directory === '' ? '/' : $directory . '/';
        try {
            $listing = (string)$ftpsRequest($path, [
                CURLOPT_CUSTOMREQUEST => 'MLSD',
                CURLOPT_TIMEOUT => 20,
            ]);
            $directoryFiles = $parseMlsd($listing, $directory);
            if ($directoryFiles === []) {
                $listing = (string)$ftpsRequest($path, [
                    CURLOPT_DIRLISTONLY => true,
                    CURLOPT_TIMEOUT => 20,
                ]);
                foreach (preg_split('/\r\n|\n|\r/', $listing) ?: [] as $name) {
                    $name = trim($name);
                    if ($name === '' || $name === '.' || $name === '..' || str_ends_with($name, '/')) {
                        continue;
                    }
                    if (!preg_match('/\.(gcode|3mf|gcode\.3mf)$/i', $name)) {
                        continue;
                    }
                    $files[] = [
                        'name' => dmd3d_clean_text(basename($name), 255),
                        'path' => dmd3d_clean_text(trim($directory . '/' . $name, '/'), 500),
                        'size' => null,
                        'modified' => null,
                        'directory' => dmd3d_clean_text($directory, 120),
                    ];
                }
            } else {
                foreach ($directoryFiles as $file) {
                    if (preg_match('/\.(gcode|3mf|gcode\.3mf)$/i', (string)($file['name'] ?? ''))) {
                        $files[] = $file;
                    }
                }
            }
        } catch (Throwable $ignored) {
            continue;
        }
    }

    $unique = [];
    foreach ($files as $file) {
        $path = strtolower((string)($file['path'] ?? ''));
        if ($path !== '') {
            $unique[$path] = $file;
        }
    }
    $files = array_values($unique);
    usort($files, static fn(array $left, array $right): int => strnatcasecmp((string)($left['name'] ?? ''), (string)($right['name'] ?? '')));

    $writeJsonCache($filesCacheFile, ['files' => $files, 'updated_at' => time()]);
    return $files;
};

$sendCommand = static function (array $request, int $qos = 1, float $wait = 1.2) use (
    $mqttExchange,
    $nextSequence
): array {
    $sequence = $nextSequence();
    $root = array_key_first($request);
    if ($root === null || !is_array($request[$root] ?? null)) {
        throw new InvalidArgumentException('Commande Bambu invalide.');
    }
    $request[$root]['sequence_id'] = $request[$root]['sequence_id'] ?? $sequence;
    $messages = $mqttExchange([$request], $wait, $qos);

    foreach ($messages as $message) {
        $response = is_array($message[$root] ?? null) ? $message[$root] : null;
        if ($response === null) {
            continue;
        }
        if ((string)($response['sequence_id'] ?? '') !== (string)$request[$root]['sequence_id']) {
            continue;
        }
        $result = strtolower(trim((string)($response['result'] ?? $response['reason'] ?? '')));
        if ($result !== '' && !in_array($result, ['success', 'ok'], true)) {
            throw new RuntimeException('La P1S a refusé la commande : ' . dmd3d_clean_text((string)($response['reason'] ?? $result), 300));
        }
        return $response;
    }

    return ['sequence_id' => (string)$request[$root]['sequence_id'], 'result' => 'sent'];
};

$commandHandler = static function (string $action, array $payload) use (
    $sendCommand,
    $statusCacheFile,
    $filesCacheFile
): array {
    if ($action === 'pause' || $action === 'resume' || $action === 'stop') {
        $sendCommand([
            'print' => [
                'command' => $action,
                'param' => '',
            ],
        ], 1, 1.4);
        @unlink($statusCacheFile);
        return ['ok' => true, 'message' => 'Commande transmise à la Bambu Lab P1S.'];
    }

    if ($action === 'start') {
        $file = trim(str_replace('\\', '/', (string)($payload['file'] ?? '')), '/');
        if ($file === '') {
            throw new InvalidArgumentException('Sélectionne un fichier présent dans la P1S.');
        }
        if (str_contains($file, '..')) {
            throw new InvalidArgumentException('Chemin de fichier invalide.');
        }

        if (preg_match('/\.gcode\.3mf$|\.3mf$/i', $file)) {
            $plate = max(1, min(99, (int)($payload['plate'] ?? 1)));
            $useAms = filter_var($payload['use_ams'] ?? false, FILTER_VALIDATE_BOOL);
            $amsMapping = $payload['ams_mapping'] ?? [];
            if (!is_array($amsMapping)) {
                $amsMapping = [];
            }
            $amsMapping = array_values(array_map(static fn($value): int => max(-1, min(255, (int)$value)), $amsMapping));

            $request = [
                'print' => [
                    'command' => 'project_file',
                    'param' => 'Metadata/plate_' . $plate . '.gcode',
                    'project_id' => '0',
                    'profile_id' => '0',
                    'task_id' => '0',
                    'subtask_id' => '0',
                    'subtask_name' => basename($file),
                    'file' => basename($file),
                    'url' => 'ftp:///' . $file,
                    'md5' => '',
                    'timelapse' => filter_var($payload['timelapse'] ?? false, FILTER_VALIDATE_BOOL),
                    'bed_type' => 'auto',
                    'bed_leveling' => filter_var($payload['bed_leveling'] ?? true, FILTER_VALIDATE_BOOL),
                    'bed_levelling' => filter_var($payload['bed_leveling'] ?? true, FILTER_VALIDATE_BOOL),
                    'flow_cali' => filter_var($payload['flow_cali'] ?? false, FILTER_VALIDATE_BOOL),
                    'vibration_cali' => filter_var($payload['vibration_cali'] ?? true, FILTER_VALIDATE_BOOL),
                    'layer_inspect' => filter_var($payload['layer_inspect'] ?? false, FILTER_VALIDATE_BOOL),
                    'use_ams' => $useAms,
                    'ams_mapping' => $amsMapping,
                ],
            ];
            $sendCommand($request, 1, 2.0);
        } elseif (preg_match('/\.gcode$/i', $file)) {
            $sendCommand([
                'print' => [
                    'command' => 'gcode_file',
                    'param' => $file,
                ],
            ], 1, 1.8);
        } else {
            throw new InvalidArgumentException('La P1S accepte ici les fichiers .gcode ou .gcode.3mf déjà tranchés.');
        }

        @unlink($statusCacheFile);
        return ['ok' => true, 'message' => 'Impression demandée à la Bambu Lab P1S.', 'file' => $file];
    }

    if ($action === 'light_on' || $action === 'light_off') {
        $sendCommand([
            'system' => [
                'command' => 'ledctrl',
                'led_node' => 'chamber_light',
                'led_mode' => $action === 'light_on' ? 'on' : 'off',
                'led_on_time' => 500,
                'led_off_time' => 500,
                'loop_times' => 1,
                'interval_time' => 1000,
            ],
        ], 1, 1.0);
        @unlink($statusCacheFile);
        return ['ok' => true, 'message' => 'Commande d’éclairage transmise à la P1S.'];
    }

    if ($action === 'fan') {
        $fan = strtolower(trim((string)($payload['fan'] ?? 'part')));
        $value = max(0, min(100, (int)($payload['value'] ?? 0)));
        $speed = max(0, min(255, (int)round(($value / 100) * 255)));
        $fanMap = ['part' => 1, 'aux' => 2, 'chamber' => 3];
        if (!isset($fanMap[$fan])) {
            throw new InvalidArgumentException('Ventilateur inconnu pour la Bambu Lab P1S.');
        }
        $sendCommand([
            'print' => [
                'command' => 'gcode_line',
                'param' => 'M106 P' . $fanMap[$fan] . ' S' . $speed,
            ],
        ], 1, 1.0);
        @unlink($statusCacheFile);
        return ['ok' => true, 'message' => 'Vitesse du ventilateur transmise à la P1S.'];
    }

    if ($action === 'speed') {
        $level = max(1, min(4, (int)($payload['level'] ?? $payload['value'] ?? 2)));
        $sendCommand([
            'print' => [
                'command' => 'print_speed',
                'param' => (string)$level,
            ],
        ], 1, 1.0);
        @unlink($statusCacheFile);
        return ['ok' => true, 'message' => 'Mode de vitesse transmis à la P1S.', 'level' => $level];
    }

    if ($action === 'refresh') {
        @unlink($statusCacheFile);
        @unlink($filesCacheFile);
        return ['ok' => true, 'message' => 'Cache de la P1S vidé.'];
    }

    throw new RuntimeException('Commande non prise en charge par le pilote P1S.');
};

$uploadHandler = static function (array $device, array $payload, array $context) use (
    $requireConnectionData,
    $host,
    $ftpPort,
    $accessCode,
    $connectTimeout,
    $uploadDirectory,
    $commandHandler,
    $filesCacheFile
): array {
    $requireConnectionData();
    if (!function_exists('curl_init')) {
        throw new RuntimeException('L’extension PHP cURL est nécessaire pour envoyer un fichier à la P1S.');
    }

    $path = (string)($payload['path'] ?? '');
    if ($path === '' || !is_file($path) || !is_readable($path)) {
        throw new RuntimeException('Le fichier temporaire à envoyer est introuvable.');
    }

    $name = trim((string)($payload['name'] ?? basename($path)));
    $extension = '';
    if (preg_match('/\.gcode\.3mf$/i', $name)) {
        $extension = '.gcode.3mf';
        $stem = substr($name, 0, -strlen($extension));
    } else {
        $extension = strtolower((string)pathinfo($name, PATHINFO_EXTENSION));
        $extension = $extension !== '' ? '.' . $extension : '';
        $stem = (string)pathinfo($name, PATHINFO_FILENAME);
    }
    $stem = preg_replace('/[^A-Za-z0-9._-]+/', '_', $stem) ?: 'print';
    $name = trim($stem, '._-') . $extension;
    if ($name === '' || !preg_match('/\.(gcode|3mf|gcode\.3mf)$/i', $name)) {
        throw new InvalidArgumentException('Le fichier doit être un .gcode ou un .gcode.3mf déjà tranché.');
    }

    $directory = trim((string)($payload['remote_directory'] ?? $uploadDirectory), '/');
    $directory = preg_replace('~[^A-Za-z0-9._/-]+~', '_', $directory) ?: '';
    $remotePath = trim(($directory !== '' ? $directory . '/' : '') . $name, '/');
    $segments = array_filter(explode('/', $remotePath), static fn(string $segment): bool => $segment !== '');
    $encodedRemotePath = implode('/', array_map('rawurlencode', $segments));
    $url = 'ftps://' . $host . ':' . $ftpPort . '/' . $encodedRemotePath;

    $stream = @fopen($path, 'rb');
    if (!is_resource($stream)) {
        throw new RuntimeException('Impossible d’ouvrir le fichier à envoyer.');
    }

    $handle = curl_init($url);
    if ($handle === false) {
        fclose($stream);
        throw new RuntimeException('Impossible de préparer l’envoi FTPS vers la P1S.');
    }

    $curlOptions = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => 'bblp:' . $accessCode,
        CURLOPT_CONNECTTIMEOUT => (int)ceil($connectTimeout),
        CURLOPT_TIMEOUT => 300,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_UPLOAD => true,
        CURLOPT_INFILE => $stream,
        CURLOPT_INFILESIZE => filesize($path),
        CURLOPT_FTP_USE_EPSV => true,
    ];
    if (defined('CURLOPT_USE_SSL') && defined('CURLUSESSL_ALL')) {
        $curlOptions[CURLOPT_USE_SSL] = CURLUSESSL_ALL;
    }
    if (defined('CURLOPT_FTPSSLAUTH') && defined('CURLFTPAUTH_TLS')) {
        $curlOptions[CURLOPT_FTPSSLAUTH] = CURLFTPAUTH_TLS;
    }
    curl_setopt_array($handle, $curlOptions);

    $body = curl_exec($handle);
    $error = curl_error($handle);
    $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
    curl_close($handle);
    fclose($stream);

    if ($body === false || ($status >= 400 && $status !== 0)) {
        throw new RuntimeException(
            'Échec de l’envoi FTPS vers la P1S'
            . ($error !== '' ? ' : ' . $error : ($status > 0 ? ' (FTP ' . $status . ')' : ''))
        );
    }

    @unlink($filesCacheFile);
    if (!empty($payload['start_after_upload'])) {
        $startPayload = $payload;
        $startPayload['file'] = $remotePath;
        $commandHandler('start', $startPayload);
    }

    return [
        'ok' => true,
        'message' => 'Fichier envoyé à la Bambu Lab P1S.',
        'remote_path' => $remotePath,
    ];
};

$cameraHandler = static function (array $device, array $payload, array $context) use (
    $requireConnectionData,
    $host,
    $cameraPort,
    $accessCode,
    $connectTimeout,
    $socketWriteAll,
    $socketReadExact
): array {
    $requireConnectionData();
    $sslContext = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
            'SNI_enabled' => false,
        ],
    ]);
    $errorNumber = 0;
    $errorMessage = '';
    $socket = @stream_socket_client(
        'tls://' . $host . ':' . $cameraPort,
        $errorNumber,
        $errorMessage,
        $connectTimeout,
        STREAM_CLIENT_CONNECT,
        $sslContext
    );
    if (!is_resource($socket)) {
        throw new RuntimeException(
            'Connexion impossible avec la caméra de la P1S'
            . ($errorMessage !== '' ? ' : ' . $errorMessage : ' (erreur ' . $errorNumber . ')')
        );
    }

    try {
        stream_set_blocking($socket, true);
        stream_set_timeout($socket, (int)ceil($connectTimeout));
        $username = str_pad(substr('bblp', 0, 32), 32, "\0");
        $password = str_pad(substr($accessCode, 0, 32), 32, "\0");
        $authPacket = pack('V4', 0x40, 0x3000, 0, 0) . $username . $password;
        $socketWriteAll($socket, $authPacket);

        $deadline = microtime(true) + max(5.0, $connectTimeout + 2.0);
        for ($attempt = 0; $attempt < 4; $attempt++) {
            $header = $socketReadExact($socket, 16, $deadline);
            $values = unpack('Vpayload_size/Vitrack/Vflags/Vreserved', $header);
            $size = (int)($values['payload_size'] ?? 0);
            if ($size <= 0 || $size > 8 * 1024 * 1024) {
                throw new RuntimeException('La caméra de la P1S a renvoyé une taille d’image invalide.');
            }
            $image = $socketReadExact($socket, $size, $deadline);
            if (str_starts_with($image, "\xFF\xD8") && str_ends_with($image, "\xFF\xD9")) {
                $base64 = base64_encode($image);
                return [
                    'ok' => true,
                    'mime' => 'image/jpeg',
                    'image' => $base64,
                    'data_url' => 'data:image/jpeg;base64,' . $base64,
                    'width' => 1280,
                    'height' => 720,
                    'captured_at' => time(),
                ];
            }
        }
        throw new RuntimeException('Aucune image JPEG valide n’a été reçue de la caméra de la P1S.');
    } finally {
        @fclose($socket);
    }
};

$statusHandler = static function (array $device, array $payload, array $context) use (
    $collectPrinterData,
    $parseAms,
    $fanPercent,
    $lightState,
    $stateLabel,
    $listFiles,
    $configuredCameraUrl,
    $cameraMode,
    $cameraEndpoint,
    $capabilities,
    $configuredNozzleMaterial,
    $configuredNozzleModel
): array {
    try {
        $data = $collectPrinterData(!empty($payload['force_refresh']));
        $print = is_array($data['state'] ?? null) ? $data['state'] : [];
        $info = is_array($data['info'] ?? null) ? $data['info'] : [];
    } catch (Throwable $error) {
        return [
            'ok' => true,
            'online' => false,
            'state' => 'Hors ligne',
            'message' => $error->getMessage(),
            'camera_url' => $configuredCameraUrl,
            'camera_mode' => $cameraMode,
            'camera_endpoint' => $cameraEndpoint,
            'capabilities' => $capabilities,
            'files' => [],
            'fans' => [],
            'cfs' => ['available' => false, 'slots' => [], 'synced_at' => null],
            'ams' => ['available' => false, 'slots' => [], 'synced_at' => null],
        ];
    }

    $gcodeState = trim((string)($print['gcode_state'] ?? ''));
    $progressPercent = is_numeric($print['mc_percent'] ?? null) ? max(0.0, min(100.0, (float)$print['mc_percent'])) : null;
    $progress = $progressPercent !== null ? $progressPercent / 100 : null;
    $remaining = is_numeric($print['mc_remaining_time'] ?? null) ? max(0.0, (float)$print['mc_remaining_time'] * 60) : null;
    $startTimestamp = is_numeric($print['gcode_start_time'] ?? null) ? (int)$print['gcode_start_time'] : 0;
    $elapsed = $startTimestamp > 0 && $startTimestamp <= time() ? max(0, time() - $startTimestamp) : null;
    $total = $elapsed !== null && $remaining !== null ? $elapsed + $remaining : null;

    $ams = $parseAms($print);
    $fans = [];
    $partFan = $fanPercent($print['cooling_fan_speed'] ?? null);
    $auxFan = $fanPercent($print['big_fan1_speed'] ?? null);
    $chamberFan = $fanPercent($print['big_fan2_speed'] ?? null);
    if ($partFan !== null) $fans['PART'] = $partFan;
    if ($auxFan !== null) $fans['AUX'] = $auxFan;
    if ($chamberFan !== null) $fans['CHAMBER'] = $chamberFan;

    $files = [];
    try {
        $files = $listFiles(!empty($payload['force_files']));
    } catch (Throwable $ignored) {
        $files = [];
    }

    $modules = is_array($info['module'] ?? null) ? $info['module'] : [];
    $firmware = '';
    foreach ($modules as $module) {
        if (!is_array($module)) continue;
        if (strtolower(trim((string)($module['name'] ?? ''))) === 'ota') {
            $firmware = trim((string)($module['sw_ver'] ?? ''));
            break;
        }
    }

    $nozzleDiameter = is_numeric($print['nozzle_diameter'] ?? null) ? round((float)$print['nozzle_diameter'], 3) : null;
    $nozzleMaterial = dmd3d_clean_text((string)($print['nozzle_type'] ?? $configuredNozzleMaterial), 80);
    $nozzleInfo = [
        'diameter_mm' => $nozzleDiameter,
        'material' => $nozzleMaterial,
        'model' => $configuredNozzleModel,
        'diameter_source' => $nozzleDiameter !== null ? 'bambu_mqtt' : '',
    ];

    return [
        'ok' => true,
        'online' => true,
        'state' => $stateLabel($gcodeState),
        'raw_state' => $gcodeState,
        'file' => dmd3d_clean_text((string)($print['gcode_file'] ?? $print['subtask_name'] ?? ''), 255),
        'progress' => $progress,
        'progress_percent' => $progressPercent,
        'elapsed' => $elapsed,
        'total' => $total,
        'remaining' => $remaining,
        'current_layer' => is_numeric($print['layer_num'] ?? null) ? (int)$print['layer_num'] : null,
        'total_layers' => is_numeric($print['total_layer_num'] ?? null) ? (int)$print['total_layer_num'] : null,
        'nozzle' => is_numeric($print['nozzle_temper'] ?? null) ? round((float)$print['nozzle_temper'], 1) : null,
        'nozzle_target' => is_numeric($print['nozzle_target_temper'] ?? null) ? round((float)$print['nozzle_target_temper'], 1) : null,
        'nozzle_info' => $nozzleInfo,
        'nozzle_diameter' => $nozzleDiameter,
        'nozzle_material' => $nozzleMaterial,
        'nozzle_model' => $configuredNozzleModel,
        'bed' => is_numeric($print['bed_temper'] ?? null) ? round((float)$print['bed_temper'], 1) : null,
        'bed_target' => is_numeric($print['bed_target_temper'] ?? null) ? round((float)$print['bed_target_temper'], 1) : null,
        'chamber' => is_numeric($print['chamber_temper'] ?? null) ? round((float)$print['chamber_temper'], 1) : null,
        'fans' => $fans,
        'light_on' => $lightState($print),
        'cfs' => $ams,
        'ams' => $ams,
        'filaments' => $ams['slots'] ?? [],
        'camera_url' => $configuredCameraUrl,
        'camera_mode' => $cameraMode,
        'camera_endpoint' => $cameraEndpoint,
        'files' => $files,
        'wifi_signal' => dmd3d_clean_text((string)($print['wifi_signal'] ?? ''), 40),
        'firmware_version' => dmd3d_clean_text($firmware, 120),
        'speed_level' => is_numeric($print['spd_lvl'] ?? null) ? (int)$print['spd_lvl'] : null,
        'speed_percent' => is_numeric($print['spd_mag'] ?? null) ? (int)$print['spd_mag'] : null,
        'hms' => is_array($print['hms'] ?? null) ? $print['hms'] : [],
        'capabilities' => $capabilities,
        'synced_at' => (int)($data['updated_at'] ?? time()),
        'from_cache' => !empty($data['from_cache']),
        'message' => 'Informations chargées depuis imprimantes/P1S/P1S.php.',
    ];
};

$detailsHandler = static function (array $device, array $payload, array $context) use (
    $collectPrinterData,
    $parseAms,
    $fanPercent,
    $lightState,
    $stateLabel,
    $configuredNozzleMaterial,
    $configuredNozzleModel,
    $serial,
    $host,
    $mqttPort,
    $ftpPort,
    $cameraPort,
    $listFiles
): array {
    $data = $collectPrinterData(true);
    $print = is_array($data['state'] ?? null) ? $data['state'] : [];
    $info = is_array($data['info'] ?? null) ? $data['info'] : [];
    $ams = $parseAms($print);

    $stringify = static function ($value): string {
        if ($value === null || $value === '') return '';
        if (is_bool($value)) return $value ? 'Oui' : 'Non';
        if (is_scalar($value)) return trim((string)$value);
        $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($encoded) ? $encoded : '';
    };

    $add = static function (array &$items, string $label, $value, string $unit = '') use ($stringify): void {
        $text = $stringify($value);
        if ($text === '') return;
        $items[] = [
            'label' => dmd3d_clean_text($label, 140),
            'value' => dmd3d_clean_text($text, 5000),
            'unit' => dmd3d_clean_text($unit, 30),
        ];
    };

    $formatSeconds = static function ($value): string {
        if (!is_numeric($value)) return '';
        $seconds = max(0, (int)round((float)$value));
        $hours = intdiv($seconds, 3600);
        $minutes = intdiv($seconds % 3600, 60);
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds % 60);
    };

    $sections = [];

    $identity = [];
    $modelLabel = trim(implode(' ', array_filter([
        (string)($device['brand'] ?? 'Bambu Lab'),
        (string)($device['device_model'] ?? 'P1S'),
    ])));
    $add($identity, 'Nom dans DoMyDesk', $device['name'] ?? '');
    $add($identity, 'Marque et modèle', $modelLabel !== '' ? $modelLabel : 'Bambu Lab P1S');
    $add($identity, 'Pilote chargé', $device['model'] ?? 'P1S');
    $add($identity, 'Adresse configurée', $host);
    $add($identity, 'Numéro de série', $serial);
    $add($identity, 'État', $stateLabel((string)($print['gcode_state'] ?? '')));
    $add($identity, 'Cycle de vie du firmware', $print['lifecycle'] ?? '');
    $add($identity, 'Carte microSD détectée', $print['sdcard'] ?? null);
    $add($identity, 'Signal Wi-Fi', $print['wifi_signal'] ?? '');
    $add($identity, 'Port MQTT TLS', $mqttPort);
    $add($identity, 'Port FTPS implicite', $ftpPort);
    $add($identity, 'Port caméra TLS', $cameraPort);
    $sections[] = ['title' => 'Identité et réseau', 'icon' => '🖨️', 'items' => $identity];

    $firmwareItems = [];
    $modules = is_array($info['module'] ?? null) ? $info['module'] : [];
    foreach ($modules as $module) {
        if (!is_array($module)) continue;
        $moduleName = trim((string)($module['name'] ?? 'Module'));
        $description = trim(implode(' · ', array_filter([
            (string)($module['sw_ver'] ?? ''),
            (string)($module['hw_ver'] ?? ''),
            (string)($module['sn'] ?? ''),
        ])));
        $add($firmwareItems, 'Module ' . $moduleName, $description);
    }
    $upgradeState = is_array($print['upgrade_state'] ?? null) ? $print['upgrade_state'] : [];
    $add($firmwareItems, 'État de la mise à jour', $upgradeState['status'] ?? '');
    $add($firmwareItems, 'Progression de la mise à jour', $upgradeState['progress'] ?? null, '%');
    $add($firmwareItems, 'Message de mise à jour', $upgradeState['message'] ?? '');
    if ($firmwareItems) $sections[] = ['title' => 'Firmwares et composants', 'icon' => '🧠', 'items' => $firmwareItems];

    $machineItems = [];
    $add($machineItems, 'Cinématique', 'CoreXY');
    $add($machineItems, 'Volume d’impression', '256 × 256 × 256', 'mm');
    $add($machineItems, 'Diamètre de buse détecté', $print['nozzle_diameter'] ?? null, 'mm');
    $add($machineItems, 'Matériau/type de buse', $print['nozzle_type'] ?? $configuredNozzleMaterial);
    $add($machineItems, 'Modèle de buse configuré', $configuredNozzleModel);
    $add($machineItems, 'Niveau de vitesse', $print['spd_lvl'] ?? null);
    $add($machineItems, 'Facteur de vitesse', $print['spd_mag'] ?? null, '%');
    $add($machineItems, 'Axes initialisés', !empty($print['home_flag']) ? 'Oui' : 'Non');
    $sections[] = ['title' => 'Machine, volume et buse', 'icon' => '📐', 'items' => $machineItems];

    $temperatureItems = [];
    $add($temperatureItems, 'Température de la buse', $print['nozzle_temper'] ?? null, '°C');
    $add($temperatureItems, 'Consigne de la buse', $print['nozzle_target_temper'] ?? null, '°C');
    $add($temperatureItems, 'Température du plateau', $print['bed_temper'] ?? null, '°C');
    $add($temperatureItems, 'Consigne du plateau', $print['bed_target_temper'] ?? null, '°C');
    $add($temperatureItems, 'Température de la chambre', $print['chamber_temper'] ?? null, '°C');
    $add($temperatureItems, 'Ventilateur de pièce', $fanPercent($print['cooling_fan_speed'] ?? null), '%');
    $add($temperatureItems, 'Ventilateur auxiliaire', $fanPercent($print['big_fan1_speed'] ?? null), '%');
    $add($temperatureItems, 'Ventilateur de chambre', $fanPercent($print['big_fan2_speed'] ?? null), '%');
    $add($temperatureItems, 'Ventilateur du heatbreak', $fanPercent($print['heatbreak_fan_speed'] ?? null), '%');
    $add($temperatureItems, 'Éclairage de chambre', $lightState($print));
    $sections[] = ['title' => 'Températures, ventilation et lumière', 'icon' => '🌡️', 'items' => $temperatureItems];

    $printItems = [];
    $remainingSeconds = is_numeric($print['mc_remaining_time'] ?? null) ? (float)$print['mc_remaining_time'] * 60 : null;
    $startTimestamp = is_numeric($print['gcode_start_time'] ?? null) ? (int)$print['gcode_start_time'] : 0;
    $elapsedSeconds = $startTimestamp > 0 && $startTimestamp <= time() ? time() - $startTimestamp : null;
    $add($printItems, 'État brut de l’impression', $print['gcode_state'] ?? '');
    $add($printItems, 'Fichier en cours', $print['gcode_file'] ?? '');
    $add($printItems, 'Nom de la tâche', $print['subtask_name'] ?? '');
    $add($printItems, 'Progression', $print['mc_percent'] ?? null, '%');
    $add($printItems, 'Couche actuelle', $print['layer_num'] ?? null);
    $add($printItems, 'Nombre total de couches', $print['total_layer_num'] ?? null);
    $add($printItems, 'Temps écoulé', $formatSeconds($elapsedSeconds));
    $add($printItems, 'Temps restant', $formatSeconds($remainingSeconds));
    $add($printItems, 'Étape principale', $print['mc_print_stage'] ?? null);
    $add($printItems, 'Sous-étape', $print['mc_print_sub_stage'] ?? null);
    $add($printItems, 'Action G-code', $print['print_gcode_action'] ?? null);
    $add($printItems, 'Action réelle', $print['print_real_action'] ?? null);
    $add($printItems, 'Préparation du fichier', $print['gcode_file_prepare_percent'] ?? null, '%');
    $add($printItems, 'Type d’impression', $print['print_type'] ?? '');
    $sections[] = ['title' => 'Impression en cours', 'icon' => '🧱', 'items' => $printItems];

    $amsItems = [];
    $add($amsItems, 'AMS disponible', $ams['available'] ?? false);
    $add($amsItems, 'État AMS', $ams['state'] ?? '');
    $add($amsItems, 'Code d’état AMS', $ams['status_code'] ?? null);
    $add($amsItems, 'État RFID AMS', $ams['rfid_status'] ?? null);
    foreach (($ams['units'] ?? []) as $unit) {
        if (!is_array($unit)) continue;
        $add($amsItems, ($unit['label'] ?? 'AMS') . ' — température', $unit['temperature'] ?? null, '°C');
        $add($amsItems, ($unit['label'] ?? 'AMS') . ' — humidité', $unit['humidity'] ?? null, '%');
    }
    foreach (($ams['slots'] ?? []) as $slot) {
        if (!is_array($slot) || empty($slot['present'])) continue;
        $description = trim(implode(' · ', array_filter([
            (string)($slot['type'] ?? ''),
            (string)($slot['name'] ?? ''),
            (string)($slot['vendor'] ?? ''),
            (string)($slot['color'] ?? ''),
            isset($slot['remain_percent']) && $slot['remain_percent'] !== null ? ((string)$slot['remain_percent'] . ' %') : '',
            !empty($slot['active']) ? 'Active' : '',
        ])));
        $add($amsItems, 'Bobine ' . ($slot['slot'] ?? '?'), $description);
    }
    $external = is_array($ams['external'] ?? null) ? $ams['external'] : [];
    if (!empty($external['present'])) {
        $description = trim(implode(' · ', array_filter([
            (string)($external['type'] ?? ''),
            (string)($external['name'] ?? ''),
            (string)($external['vendor'] ?? ''),
            (string)($external['color'] ?? ''),
            !empty($external['active']) ? 'Active' : '',
        ])));
        $add($amsItems, 'Porte-bobine externe', $description);
    }
    if ($amsItems) $sections[] = ['title' => 'AMS et filaments', 'icon' => '🧵', 'items' => $amsItems];

    $cameraItems = [];
    $ipcam = is_array($print['ipcam'] ?? null) ? $print['ipcam'] : [];
    $add($cameraItems, 'Caméra détectée', $ipcam['ipcam_dev'] ?? null);
    $add($cameraItems, 'Résolution signalée', $ipcam['resolution'] ?? '');
    $add($cameraItems, 'Enregistrement vidéo', $ipcam['ipcam_record'] ?? '');
    $add($cameraItems, 'Timelapse', $ipcam['timelapse'] ?? '');
    $add($cameraItems, 'État caméra', $print['xcam_status'] ?? '');
    $xcam = is_array($print['xcam'] ?? null) ? $print['xcam'] : [];
    foreach ($xcam as $name => $value) {
        $add($cameraItems, 'Caméra — ' . str_replace('_', ' ', (string)$name), $value);
    }
    if ($cameraItems) $sections[] = ['title' => 'Caméra et détection', 'icon' => '📷', 'items' => $cameraItems];

    $storageItems = [];
    try {
        $files = $listFiles(true);
        $add($storageItems, 'Nombre de fichiers imprimables trouvés', count($files));
        foreach (array_slice($files, 0, 30) as $file) {
            if (!is_array($file)) continue;
            $description = (string)($file['path'] ?? $file['name'] ?? '');
            if (is_numeric($file['size'] ?? null)) {
                $description .= ' · ' . number_format(((float)$file['size']) / 1048576, 2, ',', ' ') . ' Mo';
            }
            $add($storageItems, 'Fichier', $description);
        }
    } catch (Throwable $error) {
        $add($storageItems, 'Accès FTPS', $error->getMessage());
    }
    $upload = is_array($print['upload'] ?? null) ? $print['upload'] : [];
    $add($storageItems, 'État du transfert', $upload['status'] ?? '');
    $add($storageItems, 'Progression du transfert', $upload['progress'] ?? null, '%');
    $add($storageItems, 'Vitesse du transfert', $upload['speed'] ?? null);
    $add($storageItems, 'Temps de transfert restant', $upload['time_remaining'] ?? null, 's');
    if ($storageItems) $sections[] = ['title' => 'Fichiers et transferts', 'icon' => '📁', 'items' => $storageItems];

    $diagnosticItems = [];
    $add($diagnosticItems, 'Code d’échec', $print['fail_reason'] ?? null);
    $add($diagnosticItems, 'Erreur d’impression', $print['print_error'] ?? null);
    $add($diagnosticItems, 'Code d’erreur MC', $print['mc_print_error_code'] ?? null);
    $hms = is_array($print['hms'] ?? null) ? $print['hms'] : [];
    foreach ($hms as $index => $error) {
        if (!is_array($error)) {
            $add($diagnosticItems, 'HMS ' . ($index + 1), $error);
            continue;
        }
        $description = trim(implode(' · ', array_filter([
            isset($error['attr']) ? 'ATTR ' . $error['attr'] : '',
            isset($error['code']) ? 'CODE ' . $error['code'] : '',
            isset($error['module']) ? 'MODULE ' . $error['module'] : '',
        ])));
        $add($diagnosticItems, 'HMS ' . ($index + 1), $description !== '' ? $description : $error);
    }
    if (!$diagnosticItems) {
        $add($diagnosticItems, 'État', 'Aucune erreur remontée');
    }
    $sections[] = ['title' => 'Erreurs HMS et diagnostic', 'icon' => '⚠️', 'items' => $diagnosticItems];

    return [
        'ok' => true,
        'summary' => [
            'name' => dmd3d_clean_text((string)($device['name'] ?? 'Bambu Lab P1S'), 120),
            'model' => dmd3d_clean_text($modelLabel !== '' ? $modelLabel : 'Bambu Lab P1S', 160),
            'state' => dmd3d_clean_text($stateLabel((string)($print['gcode_state'] ?? '')), 80),
            'state_message' => dmd3d_clean_text((string)($print['mc_print_error_code'] ?? ''), 500),
            'hostname' => dmd3d_clean_text($host, 120),
            'firmware_version' => dmd3d_clean_text((string)($modules[0]['sw_ver'] ?? ''), 120),
            'serial' => dmd3d_clean_text($serial, 120),
        ],
        'details_sections' => $sections,
        'collected_at' => time(),
        'message' => 'Informations détaillées chargées depuis imprimantes/P1S/P1S.php.',
    ];
};

return [
    'status' => $statusHandler,
    'details' => $detailsHandler,
    'start' => static fn(array $device, array $payload, array $context): array => $commandHandler('start', $payload),
    'pause' => static fn(array $device, array $payload, array $context): array => $commandHandler('pause', $payload),
    'resume' => static fn(array $device, array $payload, array $context): array => $commandHandler('resume', $payload),
    'stop' => static fn(array $device, array $payload, array $context): array => $commandHandler('stop', $payload),
    'light_on' => static fn(array $device, array $payload, array $context): array => $commandHandler('light_on', $payload),
    'light_off' => static fn(array $device, array $payload, array $context): array => $commandHandler('light_off', $payload),
    'fan' => static fn(array $device, array $payload, array $context): array => $commandHandler('fan', $payload),
    'speed' => static fn(array $device, array $payload, array $context): array => $commandHandler('speed', $payload),
    'refresh' => static fn(array $device, array $payload, array $context): array => $commandHandler('refresh', $payload),
    'upload_file' => $uploadHandler,
    'camera_snapshot' => $cameraHandler,
    'camera_frame' => $cameraHandler,
];