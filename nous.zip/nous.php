<?php
declare(strict_types=1);

/*
 * Pilote du modèle de prise NOUS.
 * Toute la logique propre à cette prise reste dans prises/NOUS/.
 */

$requestCommand = static function (array $device, string $command): array {
    $baseUrl = dmd3d_device_base_url($device);
    $response = dmd3d_http_request(
        $baseUrl . '/cm?cmnd=' . rawurlencode($command),
        'GET',
        null,
        [],
        3.0
    );
    if (!$response['ok'] || !is_array($response['json'])) {
        throw new RuntimeException('La prise ne répond pas correctement.');
    }
    return $response['json'];
};

return [
    'status' => static function (array $device, array $payload, array $context) use ($requestCommand): array {
        try {
            $powerResponse = $requestCommand($device, 'Power');
            $energyResponse = $requestCommand($device, 'Status 8');
        } catch (Throwable $error) {
            return [
                'ok' => true,
                'online' => false,
                'state' => 'offline',
                'message' => $error->getMessage(),
                'capabilities' => ['power' => true, 'energy' => true],
            ];
        }

        $energy = is_array($energyResponse['StatusSNS']['ENERGY'] ?? null)
            ? $energyResponse['StatusSNS']['ENERGY']
            : [];
        $powerState = strtoupper((string)($powerResponse['POWER'] ?? $powerResponse['Power'] ?? ''));

        // --- CORRECTION DE LA TENSION (VOLTAGE) ---
        $voltage = $energy['Voltage'] ?? null;
        $powerW = $energy['Power'] ?? null;
        $current = $energy['Current'] ?? null;

        // Si le voltage retourné est faux/anormal (ex: 34V) mais qu'on a de la puissance et du courant, 
        // on applique la formule électrique U = P / I pour retrouver les ~230V.
        if ($voltage !== null && $voltage < 100 && $powerW > 0 && $current > 0) {
            $voltage = (int) round($powerW / $current);
        }
        // ------------------------------------------

        return [
            'ok' => true,
            'online' => true,
            'state' => $powerState === 'ON' ? 'on' : ($powerState === 'OFF' ? 'off' : 'connected'),
            'voltage' => $voltage, // Utilise la variable corrigée
            'power_w' => $powerW,
            'current' => $current,
            'energy' => $energy['Total'] ?? $energy['Today'] ?? null,
            'energy_today' => $energy['Today'] ?? null,
            'apparent_power' => $energy['ApparentPower'] ?? null,
            'reactive_power' => $energy['ReactivePower'] ?? null,
            'factor' => $energy['Factor'] ?? null,
            'capabilities' => ['power' => true, 'energy' => true],
            'message' => 'Informations chargées depuis prises/NOUS/nous.php (Tension corrigée).',
        ];
    },

    'power_on' => static function (array $device, array $payload, array $context) use ($requestCommand): array {
        $result = $requestCommand($device, 'Power ON');
        return [
            'ok' => true,
            'state' => strtolower((string)($result['POWER'] ?? 'ON')),
            'message' => 'Prise allumée.',
        ];
    },

    'power_off' => static function (array $device, array $payload, array $context) use ($requestCommand): array {
        $result = $requestCommand($device, 'Power OFF');
        return [
            'ok' => true,
            'state' => strtolower((string)($result['POWER'] ?? 'OFF')),
            'message' => 'Prise éteinte.',
        ];
    },
];