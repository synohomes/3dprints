<?php
declare(strict_types=1);

/*
 * Pilote du modèle K2PRO.
 * Toute la logique propre à cette imprimante reste dans imprimantes/K2PRO/.
 */

$options = is_array($device['options'] ?? null) ? $device['options'] : [];
$host = trim((string)($device['host'] ?? ''));
$apiProtocol = strtolower(trim((string)($options['api_protocol'] ?? 'http')));
$apiProtocol = in_array($apiProtocol, ['http', 'https'], true) ? $apiProtocol : 'http';
$apiPort = max(1, min(65535, (int)($options['api_port'] ?? 7125)));
$cameraProtocol = strtolower(trim((string)($options['camera_protocol'] ?? 'http')));
$cameraProtocol = in_array($cameraProtocol, ['http', 'https'], true) ? $cameraProtocol : 'http';
$cameraPort = max(1, min(65535, (int)($options['camera_port'] ?? 8000)));
$apiBase = $apiProtocol . '://' . $host . ':' . $apiPort;
$cameraBase = $cameraProtocol . '://' . $host . ':' . $cameraPort;
$configuredCameraUrl = trim((string)($device['camera_url'] ?? ''));
$cameraUrl = $configuredCameraUrl !== '' ? $configuredCameraUrl : $cameraBase . '/stream';
$cameraMode = trim((string)($options['camera_mode'] ?? ($configuredCameraUrl === '' ? 'webrtc_base64' : '')));
$cameraEndpoint = trim((string)($options['camera_endpoint'] ?? ($cameraMode === 'webrtc_base64' ? $cameraBase . '/call/webrtc_local' : '')));

$request = static function (
    string $url,
    string $method = 'GET',
    ?string $body = null,
    array $headers = [],
    float $timeout = 4.0
): array {
    $response = dmd3d_http_request($url, $method, $body, $headers, $timeout);
    if (!$response['ok']) {
        throw new RuntimeException('L’imprimante a répondu HTTP ' . $response['status'] . '.');
    }
    return $response;
};

$apiRequest = static function (
    string $path,
    string $method = 'GET',
    ?string $body = null,
    array $headers = [],
    float $timeout = 4.0
) use ($request, $apiBase): array {
    return $request($apiBase . $path, $method, $body, $headers, $timeout);
};

$cleanColor = static function ($value): string {
    if (is_array($value)) {
        $red = $value['r'] ?? $value['red'] ?? $value[0] ?? null;
        $green = $value['g'] ?? $value['green'] ?? $value[1] ?? null;
        $blue = $value['b'] ?? $value['blue'] ?? $value[2] ?? null;
        if (is_numeric($red) && is_numeric($green) && is_numeric($blue)) {
            $channels = [(float)$red, (float)$green, (float)$blue];
            if (max($channels) <= 1.0) {
                $channels = array_map(static fn(float $channel): float => $channel * 255, $channels);
            }
            return sprintf('#%02X%02X%02X',
                max(0, min(255, (int)round($channels[0]))),
                max(0, min(255, (int)round($channels[1]))),
                max(0, min(255, (int)round($channels[2])))
            );
        }
        return '';
    }
    if (is_int($value) || (is_string($value) && ctype_digit(trim($value)))) {
        $numeric = (int)$value;
        if ($numeric >= 0 && $numeric <= 0xFFFFFF) {
            return sprintf('#%06X', $numeric);
        }
    }

    $color = trim((string)$value);
    if ($color === '') {
        return '';
    }

    if (preg_match('/^#?([0-9a-f]{6})$/i', $color, $match)) {
        return '#' . strtoupper($match[1]);
    }
    /* La K2 Pro renvoie notamment les couleurs CFS sous la forme 0RRGGBB. */
    if (preg_match('/^0([0-9a-f]{6})$/i', $color, $match)) {
        return '#' . strtoupper($match[1]);
    }
    if (preg_match('/^#?([0-9a-f]{8})$/i', $color, $match)) {
        $hex = strtoupper($match[1]);
        return '#' . substr($hex, 2, 6);
    }
    if (preg_match('/^0x([0-9a-f]{6,8})$/i', $color, $match)) {
        $hex = strtoupper($match[1]);
        return '#' . substr($hex, -6);
    }
    if (preg_match('/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/i', $color, $match)) {
        return sprintf(
            '#%02X%02X%02X',
            max(0, min(255, (int)$match[1])),
            max(0, min(255, (int)$match[2])),
            max(0, min(255, (int)$match[3]))
        );
    }
    if (preg_match('/^[a-z]{3,24}$/i', $color)) {
        return strtolower($color);
    }
    return '';
};

$isEmptyCfsValue = static function ($value): bool {
    if ($value === null) return true;
    return in_array(strtoupper(trim((string)$value)), ['', '-1', 'NONE', 'NULL', 'UNKNOWN', 'N/A'], true);
};

$parseCfs = static function (array $box, array $filamentRack) use ($cleanColor, $isEmptyCfsValue): array {
    $materialNamesByCode = [];
    $materialBySlot = [];
    foreach (($box['same_material'] ?? []) as $group) {
        if (!is_array($group)) continue;
        $code = trim((string)($group[0] ?? ''));
        $color = trim((string)($group[1] ?? ''));
        $slotNames = is_array($group[2] ?? null) ? $group[2] : [];
        $name = strtoupper(trim((string)($group[3] ?? '')));
        if (!$isEmptyCfsValue($code) && $name !== '') $materialNamesByCode[$code] = $name;
        foreach ($slotNames as $slotName) {
            $slotName = strtoupper(trim((string)$slotName));
            if ($slotName !== '') $materialBySlot[$slotName] = ['code' => $code, 'name' => $name, 'color' => $color];
        }
    }

    $slots = [];
    foreach (['T1', 'T2', 'T3', 'T4'] as $unitName) {
        $unit = is_array($box[$unitName] ?? null) ? $box[$unitName] : [];
        $unitState = strtoupper(trim((string)($unit['state'] ?? '')));
        if ($unit === [] || !in_array($unitState, ['CONNECT', 'CONNECTED', 'ONLINE'], true)) continue;
        $colors = is_array($unit['color_value'] ?? null) ? array_values($unit['color_value']) : [];
        $materials = is_array($unit['material_type'] ?? null) ? array_values($unit['material_type']) : [];
        $vendors = is_array($unit['vender'] ?? null) ? array_values($unit['vender']) : [];
        $remainLengths = is_array($unit['remain_len'] ?? null) ? array_values($unit['remain_len']) : [];

        for ($index = 0; $index < 4; $index++) {
            $slotName = $unitName . chr(65 + $index);
            $materialCode = trim((string)($materials[$index] ?? ''));
            $colorRaw = trim((string)($colors[$index] ?? ''));
            $hint = $materialBySlot[$slotName] ?? [];
            if ($isEmptyCfsValue($materialCode) && !empty($hint['code'])) $materialCode = (string)$hint['code'];
            if ($isEmptyCfsValue($colorRaw) && !empty($hint['color'])) $colorRaw = (string)$hint['color'];
            $vendor = $vendors[$index] ?? null;
            $remain = $remainLengths[$index] ?? null;
            $identified = !$isEmptyCfsValue($materialCode) || !$isEmptyCfsValue($colorRaw);
            $present = $identified || !$isEmptyCfsValue($vendor) || !$isEmptyCfsValue($remain);
            $materialName = '';
            if (!empty($hint['name'])) $materialName = strtoupper(trim((string)$hint['name']));
            elseif (!$isEmptyCfsValue($materialCode)) $materialName = $materialNamesByCode[$materialCode] ?? strtoupper($materialCode);

            $slots[] = [
                'slot' => $slotName,
                'unit' => $unitName,
                'label' => substr($slotName, 1),
                'type' => $present ? dmd3d_clean_text($materialName, 40) : '',
                'material_code' => $isEmptyCfsValue($materialCode) ? '' : dmd3d_clean_text($materialCode, 40),
                'color' => $isEmptyCfsValue($colorRaw) ? '' : $cleanColor($colorRaw),
                'present' => $present,
                'identified' => $identified,
                'active' => false,
                'vendor' => $isEmptyCfsValue($vendor) ? '' : dmd3d_clean_text((string)$vendor, 80),
            ];
        }
    }

    $loadedMaterial = trim((string)($filamentRack['remain_material_type'] ?? ''));
    $loadedColor = $isEmptyCfsValue($filamentRack['remain_material_color'] ?? null)
        ? ''
        : $cleanColor($filamentRack['remain_material_color']);
    foreach ($slots as &$slot) {
        $sameMaterial = !$isEmptyCfsValue($loadedMaterial) && ($slot['material_code'] ?? '') === $loadedMaterial;
        $sameColor = $loadedColor !== '' && strtoupper((string)($slot['color'] ?? '')) === strtoupper($loadedColor);
        if (!empty($slot['present']) && (($sameMaterial && ($loadedColor === '' || $sameColor)) || ($sameColor && $isEmptyCfsValue($loadedMaterial)))) {
            $slot['active'] = true;
            break;
        }
    }
    unset($slot);

    $externalCode = trim((string)($filamentRack['material_type'] ?? ''));
    $externalColorRaw = trim((string)($filamentRack['color_value'] ?? ''));
    $externalVendor = $filamentRack['vender'] ?? ($filamentRack['vendor'] ?? null);
    $externalPresent = !$isEmptyCfsValue($externalCode) || !$isEmptyCfsValue($externalColorRaw) || !$isEmptyCfsValue($externalVendor);
    $externalColor = $isEmptyCfsValue($externalColorRaw) ? '' : $cleanColor($externalColorRaw);
    $externalName = !$isEmptyCfsValue($externalCode) ? ($materialNamesByCode[$externalCode] ?? strtoupper($externalCode)) : '';
    $slotAlreadyActive = false;
    foreach ($slots as $slot) {
        if (!empty($slot['active'])) { $slotAlreadyActive = true; break; }
    }
    $externalActive = false;
    if ($externalPresent && !$slotAlreadyActive) {
        $sameMaterial = !$isEmptyCfsValue($loadedMaterial) && !$isEmptyCfsValue($externalCode) && $loadedMaterial === $externalCode;
        $sameColor = $loadedColor !== '' && $externalColor !== '' && strtoupper($loadedColor) === strtoupper($externalColor);
        $externalActive = ($sameMaterial && ($loadedColor === '' || $sameColor)) || ($sameColor && $isEmptyCfsValue($loadedMaterial));
    }

    $unit = is_array($box['T1'] ?? null) ? $box['T1'] : [];
    return [
        'available' => in_array(strtoupper(trim((string)($box['state'] ?? ''))), ['CONNECT', 'CONNECTED', 'ONLINE'], true),
        'state' => dmd3d_clean_text((string)($box['state'] ?? ''), 40),
        'auto_refill' => isset($box['auto_refill']) ? (bool)$box['auto_refill'] : null,
        'temperature' => is_numeric($unit['temperature'] ?? null) ? (float)$unit['temperature'] : null,
        'humidity' => is_numeric($unit['dry_and_humidity'] ?? null) ? (float)$unit['dry_and_humidity'] : null,
        'external' => [
            'label' => 'Porte-bobine',
            'type' => $externalPresent ? dmd3d_clean_text($externalName, 40) : '',
            'material_code' => $isEmptyCfsValue($externalCode) ? '' : dmd3d_clean_text($externalCode, 40),
            'color' => $externalColor,
            'present' => $externalPresent,
            'identified' => !$isEmptyCfsValue($externalCode) || !$isEmptyCfsValue($externalColorRaw),
            'active' => $externalActive,
            'vendor' => $isEmptyCfsValue($externalVendor) ? '' : dmd3d_clean_text((string)$externalVendor, 80),
        ],
        'slots' => $slots,
        'synced_at' => time(),
    ];
};

$nozzleOptions = is_array($options['nozzle'] ?? null) ? $options['nozzle'] : [];
$configuredNozzleMaterial = dmd3d_clean_text((string)(
    $nozzleOptions['material'] ?? $options['nozzle_material'] ?? ''
), 80);
$configuredNozzleModel = dmd3d_clean_text((string)(
    $nozzleOptions['model'] ?? $options['nozzle_model'] ?? ''
), 120);

$capabilities = [
    'camera' => true,
    'upload' => true,
    'print_control' => true,
    'light' => true,
    'fans' => ['part', 'aux', 'chamber'],
    'files' => true,
    'cfs' => true,
    'plug' => true,
];

$statusHandler = static function (array $device, array $payload, array $context) use (
    $apiRequest,
    $parseCfs,
    $cameraUrl,
    $cameraMode,
    $cameraEndpoint,
    $capabilities,
    $configuredNozzleMaterial,
    $configuredNozzleModel
): array {

    try {
        $query = '/printer/objects/query?'
            . 'extruder=temperature,target&heater_bed=temperature,target'
            . '&print_stats=filename,print_duration,total_duration,state'
            . '&display_status=progress'
            . '&temperature_sensor%20chamber_temp=temperature';
        $response = $apiRequest($query, 'GET', null, [], 3.0);
        $status = is_array($response['json']['result']['status'] ?? null) ? $response['json']['result']['status'] : [];
    } catch (Throwable $error) {
        return [
            'ok' => true,
            'online' => false,
            'state' => 'Hors ligne',
            'message' => $error->getMessage(),
            'camera_url' => $cameraUrl,
            'camera_mode' => $cameraMode,
            'camera_endpoint' => $cameraEndpoint,
            'capabilities' => $capabilities,
            'files' => [],
            'fans' => [],
            'cfs' => ['available' => false, 'slots' => [], 'synced_at' => null],
        ];
    }

    $printStats = is_array($status['print_stats'] ?? null) ? $status['print_stats'] : [];
    $display = is_array($status['display_status'] ?? null) ? $status['display_status'] : [];
    $elapsed = is_numeric($printStats['print_duration'] ?? null) ? (float)$printStats['print_duration'] : null;
    $total = is_numeric($printStats['total_duration'] ?? null) ? (float)$printStats['total_duration'] : null;
    $progress = is_numeric($display['progress'] ?? null) ? (float)$display['progress'] : null;
    $remaining = ($elapsed !== null && $progress !== null && $progress > 0)
        ? max(0, ($elapsed / $progress) - $elapsed)
        : null;
    if (($total === null || $total <= 0) && $elapsed !== null && $remaining !== null) $total = $elapsed + $remaining;

    /*
     * Le diamètre est lu depuis la configuration Klipper réellement chargée.
     * Le matériau et le modèle ne sont pas fournis par Klipper : ils peuvent
     * être renseignés dans les options du pilote avec nozzle_material /
     * nozzle_model, ou dans l'objet JSON nozzle { material, model }.
     */
    $nozzleDiameter = null;
    try {
        $configResponse = $apiRequest('/printer/objects/query?configfile=settings', 'GET', null, [], 3.0);
        $configStatus = is_array($configResponse['json']['result']['status'] ?? null)
            ? $configResponse['json']['result']['status']
            : [];
        $configFile = is_array($configStatus['configfile'] ?? null) ? $configStatus['configfile'] : [];
        $settings = is_array($configFile['settings'] ?? null) ? $configFile['settings'] : [];
        $extruderSettings = is_array($settings['extruder'] ?? null) ? $settings['extruder'] : [];
        $diameterRaw = $extruderSettings['nozzle_diameter'] ?? null;
        if (is_numeric($diameterRaw)) {
            $diameter = (float)$diameterRaw;
            if ($diameter > 0 && $diameter <= 5) {
                $nozzleDiameter = round($diameter, 3);
            }
        }
    } catch (Throwable $ignored) {}

    $nozzleInfo = [
        'diameter_mm' => $nozzleDiameter,
        'material' => $configuredNozzleMaterial,
        'model' => $configuredNozzleModel,
        'diameter_source' => $nozzleDiameter !== null ? 'klipper_config' : '',
    ];

    $files = [];
    try {
        $filesResponse = $apiRequest('/server/files/list?root=gcodes', 'GET', null, [], 3.0);
        $files = dmd3d_normalize_file_list($filesResponse['json']['result'] ?? []);
    } catch (Throwable $ignored) {}

    $cfs = ['available' => false, 'slots' => [], 'synced_at' => null];
    try {
        $cfsResponse = $apiRequest('/printer/objects/query?box&filament_rack', 'GET', null, [], 3.0);
        $cfsStatus = is_array($cfsResponse['json']['result']['status'] ?? null) ? $cfsResponse['json']['result']['status'] : [];
        $box = is_array($cfsStatus['box'] ?? null) ? $cfsStatus['box'] : [];
        $rack = is_array($cfsStatus['filament_rack'] ?? null) ? $cfsStatus['filament_rack'] : [];
        $cfs = $parseCfs($box, $rack);
    } catch (Throwable $ignored) {}

    $lightValue = null;
    try {
        $lightResponse = $apiRequest('/printer/objects/query?output_pin%20LED=value', 'GET', null, [], 2.0);
        $lightStatus = is_array($lightResponse['json']['result']['status'] ?? null) ? $lightResponse['json']['result']['status'] : [];
        $light = is_array($lightStatus['output_pin LED'] ?? null) ? $lightStatus['output_pin LED'] : [];
        $lightValue = is_numeric($light['value'] ?? null) ? (float)$light['value'] : null;
    } catch (Throwable $ignored) {}

    $fanStatus = [];
    try {
        $fanResponse = $apiRequest(
            '/printer/objects/query?output_pin%20fan0=value&output_pin%20fan1=value&output_pin%20fan2=value&temperature_fan%20chamber_fan=speed',
            'GET',
            null,
            [],
            2.5
        );
        $fanStatus = is_array($fanResponse['json']['result']['status'] ?? null) ? $fanResponse['json']['result']['status'] : [];
    } catch (Throwable $ignored) {}

    $fans = [];
    $fanMap = [
        'PART' => ['output_pin fan0', 'value'],
        'AUX' => ['output_pin fan2', 'value'],
        'CHAMBER' => ['temperature_fan chamber_fan', 'speed'],
    ];
    foreach ($fanMap as $label => [$object, $field]) {
        $raw = $fanStatus[$object][$field] ?? null;
        if (is_numeric($raw)) $fans[$label] = max(0, min(100, (int)round((float)$raw * 100)));
    }

    $state = trim((string)($printStats['state'] ?? ''));
    return [
        'ok' => true,
        'online' => true,
        'state' => $state !== '' ? $state : 'En ligne',
        'file' => dmd3d_clean_text((string)($printStats['filename'] ?? ''), 255),
        'progress' => $progress,
        'elapsed' => $elapsed,
        'total' => $total,
        'remaining' => $remaining,
        'nozzle' => is_numeric($status['extruder']['temperature'] ?? null) ? round((float)$status['extruder']['temperature'], 1) : null,
        'nozzle_info' => $nozzleInfo,
        'nozzle_diameter' => $nozzleDiameter,
        'nozzle_material' => $configuredNozzleMaterial,
        'nozzle_model' => $configuredNozzleModel,
        'bed' => is_numeric($status['heater_bed']['temperature'] ?? null) ? round((float)$status['heater_bed']['temperature'], 1) : null,
        'chamber' => is_numeric($status['temperature_sensor chamber_temp']['temperature'] ?? null) ? round((float)$status['temperature_sensor chamber_temp']['temperature'], 1) : null,
        'fans' => $fans,
        'light_on' => $lightValue !== null ? $lightValue > 0.01 : null,
        'light_value' => $lightValue,
        'cfs' => $cfs,
        'filaments' => $cfs['slots'] ?? [],
        'camera_url' => $cameraUrl,
        'camera_mode' => $cameraMode,
        'camera_endpoint' => $cameraEndpoint,
        'files' => $files,
        'capabilities' => $capabilities,
        'message' => 'Informations chargées depuis imprimantes/K2PRO/K2PRO.php.',
    ];
};

$commandHandler = static function (string $action, array $payload) use ($apiRequest): array {
    if ($action === 'start') {
        $file = trim((string)($payload['file'] ?? ''));
        if ($file === '') throw new InvalidArgumentException('Sélectionne un fichier présent dans l’imprimante.');
        $apiRequest('/printer/print/start?filename=' . rawurlencode($file), 'POST', '');
        return ['ok' => true, 'message' => 'Impression démarrée.', 'file' => $file];
    }
    $paths = [
        'pause' => '/printer/print/pause',
        'resume' => '/printer/print/resume',
        'stop' => '/printer/print/cancel',
    ];
    if (isset($paths[$action])) {
        $apiRequest($paths[$action], 'POST', '');
        return ['ok' => true, 'message' => 'Commande transmise à l’imprimante.'];
    }
    if ($action === 'light_on' || $action === 'light_off') {
        $value = $action === 'light_on' ? '1' : '0';
        $apiRequest('/printer/gcode/script?script=' . rawurlencode('SET_PIN PIN=LED VALUE=' . $value), 'POST', '');
        return ['ok' => true, 'message' => 'Commande de lumière transmise.'];
    }
    if ($action === 'fan') {
        $fan = strtolower(trim((string)($payload['fan'] ?? 'part')));
        $speed = max(0, min(100, (int)($payload['value'] ?? 0))) / 100;
        if ($fan === 'part') $script = 'SET_PIN PIN=fan0 VALUE=' . number_format($speed, 2, '.', '');
        elseif ($fan === 'aux') $script = 'SET_PIN PIN=fan2 VALUE=' . number_format($speed, 2, '.', '');
        elseif ($fan === 'chamber') $script = 'SET_FAN_SPEED FAN=chamber_fan SPEED=' . number_format($speed, 2, '.', '');
        else throw new InvalidArgumentException('Ventilateur inconnu pour ce modèle.');
        $apiRequest('/printer/gcode/script?script=' . rawurlencode($script), 'POST', '');
        return ['ok' => true, 'message' => 'Vitesse du ventilateur transmise.'];
    }
    throw new RuntimeException('Commande non prise en charge par ce pilote.');
};

$uploadHandler = static function (array $device, array $payload, array $context) use ($apiBase, $commandHandler): array {
    $path = (string)($payload['path'] ?? '');
    if ($path === '' || !is_file($path)) throw new RuntimeException('Le fichier temporaire à envoyer est introuvable.');
    $name = trim((string)($payload['name'] ?? basename($path)));
    $url = $apiBase . '/server/files/upload';

    if (function_exists('curl_init') && class_exists('CURLFile')) {
        $handle = curl_init($url);
        if ($handle === false) throw new RuntimeException('Impossible de préparer l’envoi.');
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($path) : 'application/octet-stream';
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'root' => 'gcodes',
                'path' => '',
                'file' => new CURLFile($path, $mime ?: 'application/octet-stream', $name),
            ],
        ]);
        $body = curl_exec($handle);
        $error = curl_error($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        curl_close($handle);
        if ($body === false || $status < 200 || $status >= 300) {
            throw new RuntimeException('Échec de l’envoi' . ($error !== '' ? ' : ' . $error : ' (HTTP ' . $status . ')'));
        }
        $decoded = json_decode((string)$body, true);
    } else {
        throw new RuntimeException('L’extension PHP cURL est nécessaire pour envoyer un fichier à cette imprimante.');
    }

    $remotePath = (string)($decoded['result']['item']['path'] ?? $decoded['result']['path'] ?? $name);
    if (!empty($payload['start_after_upload'])) $commandHandler('start', ['file' => $remotePath]);
    return ['ok' => true, 'message' => 'Fichier envoyé à l’imprimante.', 'remote_path' => $remotePath];
};

$cameraHandler = static function (array $device, array $payload, array $context) use ($request, $cameraEndpoint, $cameraBase): array {
    $offer = trim((string)($payload['offer'] ?? ''));
    if ($offer === '' || strlen($offer) > 250000 || !preg_match('/^[A-Za-z0-9+\/=]+$/', $offer)) {
        throw new InvalidArgumentException('Offre WebRTC invalide.');
    }
    $endpoint = $cameraEndpoint !== '' ? $cameraEndpoint : $cameraBase . '/call/webrtc_local';
    $response = $request(
        $endpoint,
        'POST',
        $offer,
        ['Content-Type: text/plain', 'Accept: */*'],
        10.0
    );
    $answer = trim((string)$response['body']);
    if ($answer === '') throw new RuntimeException('La caméra a renvoyé une réponse vide.');
    $decodedAnswer = base64_decode($answer, true);
    $answerJson = $decodedAnswer !== false ? json_decode($decodedAnswer, true) : null;
    if (!is_array($answerJson) || ($answerJson['type'] ?? '') !== 'answer' || empty($answerJson['sdp'])) {
        throw new RuntimeException('Réponse WebRTC invalide.');
    }
    return ['ok' => true, 'answer' => $answer];
};

return [
    'status' => $statusHandler,
    'start' => static fn(array $device, array $payload, array $context): array => $commandHandler('start', $payload),
    'pause' => static fn(array $device, array $payload, array $context): array => $commandHandler('pause', $payload),
    'resume' => static fn(array $device, array $payload, array $context): array => $commandHandler('resume', $payload),
    'stop' => static fn(array $device, array $payload, array $context): array => $commandHandler('stop', $payload),
    'light_on' => static fn(array $device, array $payload, array $context): array => $commandHandler('light_on', $payload),
    'light_off' => static fn(array $device, array $payload, array $context): array => $commandHandler('light_off', $payload),
    'fan' => static fn(array $device, array $payload, array $context): array => $commandHandler('fan', $payload),
    'upload_file' => $uploadHandler,
    'camera_webrtc' => $cameraHandler,
];
